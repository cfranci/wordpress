<?php 

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

get_template_part( 'blog/loop/blog', 'articlestart');

get_template_part( 'blog/includes/format' );
