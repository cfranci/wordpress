<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
    
echo '</div>'; 
echo '</div>';
echo '</section>';