<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
    
echo '<section class="blog-page pix-recent-blog-posts newsection loadmore-wrap">';
echo '<div class="container">';
echo '<div class="row">';