<?php
	configurator_require_file ( CONFIGURATOR_PLUGINS . '/aq_resizer.php' ); //Image Resize