<?php
configurator_require_file ( CONFIGURATOR_WIDGETS . '/recent-post.php');